# Country lookup data

IP Geolocation by DB-IP, DB-IP Country Lite, snapshot June 2026 (CC BY 4.0).
https://db-ip.com/db/lite.php

The binary was obtained via the ip-location-db distribution (2026060120).
Only the country ISO code is used. The source is attributed in the admin interface.
Provide a newer compatible Country MMDB through GEOIP_COUNTRY_FILE to replace this snapshot.
