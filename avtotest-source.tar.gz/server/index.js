import 'dotenv/config'
import express from 'express'
import helmet from 'helmet'
import { ipKeyGenerator, rateLimit } from 'express-rate-limit'
import UAParser from 'ua-parser-js'
import { randomUUID } from 'node:crypto'
import { isIP } from 'node:net'
import { createReadStream } from 'node:fs'
import { setTimeout as delay } from 'node:timers/promises'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { migrate, pool, transaction } from './db.js'
import { editTopics } from './bank.js'
import { appError, catalog, history, readOrUpdate, start } from './exams.js'
import { digest, emailPattern, hashPassword, newToken, normalizeEmail, passwordMatches, passwordOk, readCookie, uuidPattern } from './security.js'

const app = express()
const root = fileURLToPath(new URL('../', import.meta.url))
const production = process.env.NODE_ENV === 'production'
const port = Number(process.env.PORT || 3000)
const host = process.env.HOST || (production ? '0.0.0.0' : '127.0.0.1')
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be an integer between 1 and 65535')
let ready = false
const cookieName = production ? '__Host-avto-session' : 'avto-session'
const proxy = Number(process.env.TRUST_PROXY_HOPS || 0)
if (!Number.isInteger(proxy) || proxy < 0 || proxy > 4) throw new Error('TRUST_PROXY_HOPS must be between 0 and 4')
const cookieOptions = { httpOnly: true, secure: production, sameSite: 'lax', path: '/' }
const cookieAge = 7 * 24 * 60 * 60 * 1000
const retention = Number(process.env.LOGIN_LOG_DAYS || 30)
if (!Number.isInteger(retention) || retention < 1 || retention > 365) throw new Error('LOGIN_LOG_DAYS must be between 1 and 365')
app.set('trust proxy', proxy)
app.disable('x-powered-by')
app.use(helmet({
  contentSecurityPolicy: { directives: { imgSrc: ["'self'", 'data:', 'blob:'], upgradeInsecureRequests: production ? [] : null } },
  strictTransportSecurity: production ? undefined : false,
}))
function unavailable(request, response) {
  response.setHeader('Cache-Control', 'no-store')
  const message = 'Xizmat vaqtincha tayyor emas.'
  if (request.path === '/health' || request.path.startsWith('/api/')) {
    return response.status(503).json({ ok: false, error: message })
  }
  return response.status(503).type('text').send(message)
}

app.get('/health', async (request, response) => {
  if (!ready) return unavailable(request, response)
  try {
    await pool.query({ text: 'SELECT 1', query_timeout: 4000 })
    response.setHeader('Cache-Control', 'no-store')
    return response.json({ ok: true })
  } catch (error) {
    console.error('PostgreSQL healthcheck:', error.code || error.name)
    return unavailable(request, response)
  }
})
app.use((request, response, next) => {
  if (!ready) return unavailable(request, response)
  next()
})
app.use('/api', (_request, response, next) => {
  response.setHeader('Cache-Control', 'no-store')
  next()
})
app.use('/api', (request, _response, next) => {
  if (['GET', 'HEAD'].includes(request.method)) return next()
  const origin = request.get('origin')
  if (request.get('sec-fetch-site') === 'cross-site') throw appError(403, 'So‘rov manbasi rad etildi.')
  if (origin) {
    const host = URL.canParse(origin) ? new URL(origin).host : ''
    const allowed = host === request.get('host') || host === request.get('x-forwarded-host') && proxy > 0
      || !production && host === '127.0.0.1:5173'
    if (!allowed) throw appError(403, 'So‘rov manbasi rad etildi.')
  }
  next()
})
app.use(express.json({ limit: '64kb' }))

async function session(request, _response, next) {
  const token = readCookie(request.headers.cookie, cookieName)
  if (!token) return next()
  request.tokenHash = digest(token)
  const { rows: [account] } = await pool.query(
    'SELECT a.id,a.name,a.email,a.role FROM session s JOIN account a ON a.id=s.account_id WHERE s.token_hash=$1 AND s.expires_at>now()',
    [request.tokenHash],
  )
  request.account = account
  next()
}
const learner = (request, _response, next) => {
  if (!request.account) throw appError(401, 'Avval tizimga kiring.')
  next()
}
const admin = (request, _response, next) => {
  if (request.account?.role !== 'admin') throw appError(403, 'Administrator huquqi talab qilinadi.')
  next()
}
const rateMessage = { error: 'Urinishlar soni oshib ketdi. Keyinroq qayta urinib ko‘ring.' }
const authLimit = rateLimit({ windowMs: 15 * 60_000, limit: 35, message: rateMessage })
const emailLimit = rateLimit({
  windowMs: 15 * 60_000, limit: 12, message: rateMessage,
  keyGenerator: req => ipKeyGenerator(req.ip) + ':' + normalizeEmail(req.body?.email).slice(0, 254),
})

let geoLookup
if (process.env.GEOIP_DISABLED !== 'true') {
  const { Reader } = await import('maxmind')
  const { readFile } = await import('node:fs/promises')
  const file = process.env.GEOIP_COUNTRY_FILE || new URL('geo/dbip-country.mmdb', import.meta.url)
  geoLookup = new Reader(await readFile(file))
}
function loginContext(request) {
  const { device, os, browser } = new UAParser((request.get('user-agent') || '').slice(0, 1000)).getResult()
  const ip = (request.ip || '').replace(/^::ffff:/, '')
  const location = geoLookup && isIP(ip) ? geoLookup.get(ip) : null
  const country = location?.country_code || location?.country?.iso_code || ''
  const network = isIP(ip) === 4 ? ip.split('.').slice(0, 3).join('.') + '.0/24' : isIP(ip) === 6 ? ipKeyGenerator(ip, 48) : ''
  const supplied = typeof request.body?.timezone === 'string' ? request.body.timezone.slice(0, 80) : ''
  let timezone = ''
  try { timezone = supplied ? new Intl.DateTimeFormat('en', { timeZone: supplied }).resolvedOptions().timeZone : '' } catch {}
  return [
    network, country, [device.vendor, device.model].filter(Boolean).join(' ').slice(0, 100) || device.type || '',
    [os.name, os.version].filter(Boolean).join(' ').slice(0, 100),
    [browser.name, browser.version].filter(Boolean).join(' ').slice(0, 100), timezone,
  ]
}

app.get('/api/auth/me', session, (request, response) => response.json({ account: request.account || null }))
app.post('/api/auth/register', authLimit, async (request, response) => {
  const email = normalizeEmail(request.body?.email)
  const { name, password, confirm } = request.body || {}
  if (!emailPattern.test(email) || email.length > 254) throw appError(400, 'Email manzilini tekshiring.')
  if (typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 80) throw appError(400, 'Ism 2–80 belgidan iborat bo‘lsin.')
  if (!passwordOk(password) || password !== confirm) throw appError(400, 'Parol 10–128 belgidan iborat bo‘lsin va tasdiqlashda takrorlansin.')
  const row = await pool.query(
    "INSERT INTO account(id,email,name,password_hash,role) VALUES($1,$2,$3,$4,'learner') ON CONFLICT(email) DO NOTHING",
    [randomUUID(), email, name.trim(), await hashPassword(password)],
  )
  if (!row.rowCount) throw appError(409, 'Bu email bilan akkaunt bor.')
  response.status(201).json({ registered: true })
})
const dummyHash = await hashPassword(newToken())
app.post('/api/auth/login', authLimit, emailLimit, session, async (request, response) => {
  const email = normalizeEmail(request.body?.email)
  const password = request.body?.password
  if (!emailPattern.test(email) || email.length > 254 || !passwordOk(password)) throw appError(401, 'Email yoki parol mos kelmadi.')
  const { rows: [account] } = await pool.query('SELECT id,email,name,role,password_hash FROM account WHERE email=$1', [email])
  const matches = await passwordMatches(password, account?.password_hash || dummyHash)
  if (!matches || !account || request.body.kind === 'admin' && account.role !== 'admin') throw appError(401, 'Email yoki parol mos kelmadi.')
  const token = newToken()
  const context = loginContext(request)
  await transaction(async client => {
    if (request.tokenHash) await client.query('DELETE FROM session WHERE token_hash=$1', [request.tokenHash])
    await client.query('INSERT INTO session(token_hash,account_id,expires_at) VALUES($1,$2,$3)', [
      digest(token), account.id, new Date(Date.now() + cookieAge),
    ])
    await client.query('INSERT INTO login_event(account_id,network,country,device,os,browser,timezone) VALUES($1,$2,$3,$4,$5,$6,$7)', [
      account.id, ...context,
    ])
  })
  response.cookie(cookieName, token, { ...cookieOptions, maxAge: cookieAge })
  const { password_hash, ...publicAccount } = account
  response.json({ account: publicAccount })
})
app.post('/api/auth/logout', session, async (request, response) => {
  if (request.tokenHash) await pool.query('DELETE FROM session WHERE token_hash=$1', [request.tokenHash])
  response.clearCookie(cookieName, cookieOptions).json({ ok: true })
})

app.get('/api/topics', async (_request, response) => response.json(await catalog()))
app.use('/api/attempts', session, learner)
app.get('/api/attempts', async (request, response) => response.json(await history(request.account.id)))
app.post('/api/attempts', async (request, response) => response.status(201).json(await start(request.account.id, request.body?.topic)))
app.use('/api/attempts/:id', (request, _response, next) => {
  if (!uuidPattern.test(request.params.id)) throw appError(404, 'Urinish topilmadi.')
  next()
})
app.get('/api/attempts/:id', async (request, response) => response.json(await readOrUpdate(request.account.id, request.params.id)))
app.put('/api/attempts/:id/answer', async (request, response) => response.json(await readOrUpdate(request.account.id, request.params.id, {
  index: request.body?.index, answer: request.body?.answer,
})))
app.post('/api/attempts/:id/finish', async (request, response) => response.json(await readOrUpdate(request.account.id, request.params.id, { finish: true })))

app.get('/api/images/:id', async (request, response) => {
  if (!uuidPattern.test(request.params.id)) throw appError(404, 'Rasm topilmadi.')
  const { rows: [image] } = await pool.query('SELECT mime,bytes FROM media WHERE id=$1', [request.params.id])
  if (!image) throw appError(404, 'Rasm topilmadi.')
  response.setHeader('Cache-Control', 'public, max-age=86400')
  response.type(image.mime).send(image.bytes)
})

app.use('/api/admin', session, admin)
app.get('/api/admin/logs', async (request, response) => {
  const search = String(request.query.q || '').trim().slice(0, 80)
  const page = Math.min(1000, Math.max(1, Number.parseInt(request.query.page, 10) || 1))
  const { rows } = await pool.query(
    `SELECT e.id,e.at,e.network,e.country,e.device,e.os,e.browser,e.timezone,a.name,a.email,a.role
      FROM login_event e JOIN account a ON a.id=e.account_id
      WHERE e.at >= now() - ($3::int * interval '1 day')
        AND (strpos(lower(a.email),lower($1))>0 OR strpos(lower(a.name),lower($1))>0)
      ORDER BY e.at DESC,e.id DESC LIMIT 51 OFFSET $2`,
    [search, (page - 1) * 50, retention],
  )
  response.json({ rows: rows.slice(0, 50), more: rows.length > 50, retention, hasGeo: Boolean(geoLookup) })
})
app.get('/api/admin/questions', async (request, response) => {
  const search = String(request.query.q || '').trim().slice(0, 100)
  const page = Math.min(1000, Math.max(1, Number.parseInt(request.query.page, 10) || 1))
  const { rows } = await pool.query(
    'SELECT * FROM question WHERE enabled AND strpos(lower(text),lower($1))>0 ORDER BY id LIMIT 31 OFFSET $2', [search, (page - 1) * 30],
  )
  response.json({ rows: rows.slice(0, 30), more: rows.length > 30 })
})

const mediaSignatures = {
  'image/png': bytes => bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])),
  'image/jpeg': bytes => bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255,
  'image/webp': bytes => bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP',
}
app.post('/api/admin/images', express.raw({ type: Object.keys(mediaSignatures), limit: '4mb' }), async (request, response) => {
  const mime = request.get('content-type')
  if (!Object.hasOwn(mediaSignatures, mime) || !Buffer.isBuffer(request.body) || !mediaSignatures[mime](request.body)) {
    throw appError(400, '4 MB gacha bo‘lgan JPG, PNG yoki WEBP rasm yuklang.')
  }
  const id = randomUUID()
  await pool.query('INSERT INTO media(id,mime,bytes) VALUES($1,$2,$3)', [id, mime, request.body])
  response.status(201).json({ image: '/api/images/' + id })
})
function cropText(value, limit) {
  return typeof value === 'string' ? value.trim().slice(0, limit) : ''
}
function questionInput(body) {
  const { topic, options, answer, image } = body
  const text = cropText(body.text, 1200)
  const explanation = cropText(body.explanation, 2500)
  const items = Array.isArray(options) ? options.map(option => cropText(option, 500)) : []
  const path = typeof image === 'string' && /^(\/official\/[0-9.]+\.webp|\/signs\/[0-9.]+\.png|\/scenarios\/[a-z0-9-]+\.webp|\/api\/images\/[a-f0-9-]{36})$/.test(image)
  if (!editTopics.includes(topic) || !text || !explanation || !path || items.length !== 4 || !items.every(Boolean)
    || new Set(items.map(item => item.toLowerCase())).size !== 4 || !Number.isInteger(answer) || answer < 0 || answer > 3) {
    throw appError(400, 'Mavzu, rasm, savol, to‘rtta turli javob va izoh talab qilinadi.')
  }
  return [topic, text, JSON.stringify(items), answer, explanation, image]
}
async function saveQuestion(request, response) {
  const data = questionInput(request.body || {})
  const id = request.params.id || randomUUID()
  if (!/^[a-z0-9.-]{1,100}$/i.test(id)) throw appError(404, 'Savol topilmadi.')
  if (request.params.id) {
    const result = await pool.query('UPDATE question SET topic=$1,text=$2,options=$3,answer=$4,explanation=$5,image=$6 WHERE id=$7 AND enabled', [...data, id])
    if (!result.rowCount) throw appError(404, 'Savol topilmadi.')
  } else {
    await pool.query('INSERT INTO question(topic,text,options,answer,explanation,image,id) VALUES($1,$2,$3,$4,$5,$6,$7)', [...data, id])
  }
  response.status(request.params.id ? 200 : 201).json({ id })
}
app.post('/api/admin/questions', saveQuestion)
app.put('/api/admin/questions/:id', saveQuestion)
app.delete('/api/admin/questions/:id', async (request, response) => {
  const result = await pool.query('UPDATE question SET enabled=false WHERE id=$1 AND enabled', [request.params.id])
  if (!result.rowCount) throw appError(404, 'Savol topilmadi.')
  response.json({ ok: true })
})

app.use('/api', (_request, response) => response.status(404).json({ error: 'Manzil topilmadi.' }))
app.use(express.static(resolve(root, 'dist'), { maxAge: '1h', setHeaders(response, path) {
  if (path.endsWith('index.html')) response.setHeader('Cache-Control', 'no-cache')
} }))
app.use(['/assets', '/official', '/scenarios', '/icons', '/signs/'], (request, response, next) => {
  if (/\.[a-zA-Z0-9]+$/.test(request.originalUrl.split('?')[0])) return response.sendStatus(404)
  next()
})
app.get('/service-worker.js', (_request, response) => {
  response.setHeader('Cache-Control', 'no-store')
  response.type('js')
  createReadStream(resolve(root, 'server', 'retire-worker.js')).pipe(response)
})
app.get('/{*path}', (_request, response) => response.sendFile(resolve(root, 'dist', 'index.html'), { maxAge: 0 }))
app.use((error, _request, response, next) => {
  if (response.headersSent) return next(error)
  const status = error.status >= 400 && error.status < 500 ? error.status : 500
  if (status === 500) console.error('Application error:', error.code || error.name)
  response.status(status).json({ error: error.type === 'entity.too.large' ? 'Fayl yoki so‘rov hajmi katta.'
    : status < 500 && !error.type ? error.message : status < 500 ? 'So‘rovni tekshiring.' : 'Xizmatda vaqtinchalik xatolik.' })
})

async function clean() {
  await pool.query('DELETE FROM session WHERE expires_at<=now()')
  await pool.query("DELETE FROM login_event WHERE at < now() - ($1::int * interval '1 day')", [retention])
}

const retryableConnectionErrors = new Set([
  'ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN', '57P01', '57P03', '53300',
])

function startupReason(error) {
  if (error.code === '28P01' || error.code === '28000') return 'PostgreSQL authentication failed. Check the DATABASE_URL service reference.'
  if (error.code === '3D000') return 'PostgreSQL database does not exist. Check the DATABASE_URL service reference.'
  if (retryableConnectionErrors.has(error.code)) return 'PostgreSQL is unreachable. Check the database service and its DATABASE_URL reference. (' + error.code + ')'
  if (error.code?.startsWith('AVTO_')) return error.message
  return 'Server initialization failed (' + (error.code || error.name) + ').'
}

async function initialize() {
  for (let attempt = 0; ; attempt++) {
    try {
      await migrate()
      return
    } catch (error) {
      if (!retryableConnectionErrors.has(error.code) || attempt === 3) throw error
      console.warn('PostgreSQL unavailable, retrying startup (' + error.code + ').')
      await delay(2000 * 2 ** attempt)
    }
  }
}

pool.on('error', error => console.error('Idle PostgreSQL connection:', error.code || error.name))
const server = app.listen(port, host)
try {
  await new Promise((resolve, reject) => {
    server.once('listening', resolve)
    server.once('error', reject)
  })
  console.log('AVTO TEST 4D listening on ' + host + ':' + port + '; initializing PostgreSQL')
  await initialize()
  await clean()
  ready = true
  console.log('AVTO TEST 4D ready')
  const cleanupTimer = setInterval(() => clean().catch(error => console.error('Cleanup error:', error.code || error.name)), 6 * 3600_000)
  cleanupTimer.unref()
  for (const signal of ['SIGTERM', 'SIGINT']) process.once(signal, () => {
    ready = false
    clearInterval(cleanupTimer)
    server.close(() => { void pool.end() })
  })
} catch (error) {
  console.error('Startup failed:', startupReason(error))
  server.close()
  await pool.end()
  process.exitCode = 1
}
