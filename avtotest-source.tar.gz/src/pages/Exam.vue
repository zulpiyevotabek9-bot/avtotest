<script setup>
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Icon from '../components/Icon.vue'
import PageHeading from '../components/PageHeading.vue'
import { account, api, dateTime } from '../services/api.js'

const route = useRoute()
const router = useRouter()
const attempt = ref(null)
const index = ref(0)
const busy = ref(false)
const issue = ref('')
const now = ref(Date.now())
const offset = ref(0)
const current = computed(() => attempt.value?.questions[index.value])
const seconds = computed(() => attempt.value ? Math.max(0, Math.ceil((+new Date(attempt.value.ends) - (now.value + offset.value)) / 1000)) : 0)
const left = computed(() => [Math.floor(seconds.value / 60), seconds.value % 60].map(value => String(value).padStart(2, '0')).join(':'))
const answered = computed(() => attempt.value?.answers.filter(item => item !== null).length || 0)
const timer = setInterval(() => { now.value = Date.now() }, 500)
onBeforeUnmount(() => clearInterval(timer))
async function request(suffix = '', method = 'GET', body) {
  if (busy.value) return
  busy.value = true
  issue.value = ''
  try {
    const started = Date.now()
    const requestedId = route.params.id
    const response = await api('/attempts/' + requestedId + suffix, { method, body })
    if (route.params.id === requestedId) {
      offset.value = response.serverTime - (started + Date.now()) / 2
      attempt.value = response
    }
  }
  catch (error) {
    issue.value = error.message
    if (!account.value) router.replace({ path:'/login', query:{next:route.fullPath} })
  } finally { busy.value = false }
}
watch(() => route.params.id, () => { index.value = 0; attempt.value = null; request() }, { immediate:true })
watch([seconds, busy], () => {
  if (!seconds.value && attempt.value && !attempt.value.finished && !busy.value && !issue.value) request()
})
function finish() {
  if (window.confirm('Test yakunlansinmi?')) request('/finish','POST')
}
</script>
<template>
  <PageHeading :heading="attempt?.title || 'Test'">
    <span v-if="attempt && !attempt.finished" class="timer-pill" :class="{urgent: seconds < 60}"><Icon name="Timer" :size="18" /> {{ left }}</span>
    <RouterLink v-else to="/tests" class="button secondary"><Icon name="ArrowLeft" :size="17" /> Testlarga qaytish</RouterLink>
  </PageHeading>
  <p v-if="issue" class="notice error" role="alert">{{ issue }} <button v-if="!attempt || !seconds" class="text-link" @click="request()">Qayta urinish</button></p>
  <p v-else-if="!attempt" class="muted">Yuklanmoqda…</p>
  <div v-if="attempt && !attempt.finished && current" class="exam-layout">
    <section class="card form-card question-card">
      <div class="eyebrow">{{ index + 1 }} / {{ attempt.questions.length }}-savol</div>
      <h2>{{ current.text }}</h2>
      <div class="question-image"><img :src="current.image" alt="Savol uchun rasm" /></div>
      <div class="answer-grid">
        <button v-for="(option,i) in current.options" :key="i" class="answer" :class="{chosen:attempt.answers[index]===i}" :aria-pressed="attempt.answers[index]===i" :disabled="busy || !seconds" @click="request('/answer','PUT',{index,answer:i})"><span>{{ 'ABCD'[i] }}</span><strong>{{ option }}</strong></button>
      </div>
      <div class="exam-controls"><button class="button secondary" :disabled="index===0" @click="index--"><Icon name="ChevronLeft" :size="16" /> Oldingi</button>
        <button v-if="index+1<attempt.questions.length" class="button primary" @click="index++">Keyingi <Icon name="ChevronRight" :size="16" /></button>
        <button v-else class="button primary" :disabled="busy" @click="finish">Yakunlash <Icon name="Check" :size="16" /></button></div>
    </section>
    <aside class="card form-card exam-side"><h2>Savollar</h2><p class="muted">{{ answered }} ta javob saqlandi</p>
      <div class="question-nav"><button v-for="(answer,i) in attempt.answers" :key="i" :class="{current:i===index,filled:answer!==null}" :aria-current="index===i ? 'step' : undefined" @click="index=i">{{ i+1 }}</button></div>
      <button class="button secondary" :disabled="busy" @click="finish">Testni yakunlash</button>
    </aside>
  </div>
  <template v-else-if="attempt?.finished">
    <div class="card score-card"><div class="score-ring" :class="{failed:attempt.score<attempt.passMark}" :style="{'--score':attempt.score+'%'}"><strong>{{ attempt.score }}%</strong></div><div><h2>{{ attempt.score>=attempt.passMark ? 'Testdan o‘tdingiz' : 'O‘tish balli yetmadi' }}</h2><p class="muted">{{ attempt.correct }} / {{ attempt.questions.length }} to‘g‘ri · {{ answered }} ta javob · {{ dateTime(attempt.finished) }}</p></div></div>
    <details v-for="(item,i) in attempt.questions" :key="item.id" class="card result-detail" :open="attempt.answers[i]!==item.answer">
      <summary><Icon :name="attempt.answers[i]===item.answer ? 'CheckCircle2' : 'XCircle'" :size="19" /><strong>{{ i+1 }}. {{ item.text }}</strong><Icon name="ChevronDown" :size="17" /></summary>
      <div class="result-copy"><div class="question-image"><img :src="item.image" alt="Savol rasmi" loading="lazy" /></div><p><strong>Sizning javobingiz</strong>{{ item.options[attempt.answers[i]] || 'Javobsiz' }}</p><p><strong>To‘g‘ri javob</strong>{{ item.options[item.answer] }}</p><p>{{ item.explanation }}</p></div>
    </details>
  </template>
</template>
