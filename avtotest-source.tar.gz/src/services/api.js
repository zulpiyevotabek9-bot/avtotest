import { ref } from 'vue'

export const account = ref(null)
export const registeredEmail = ref('')
let initial

export async function api(path, { method = 'GET', body } = {}) {
  const headers = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = body instanceof Blob ? body.type : 'application/json'
  const response = await fetch('/api' + path, {
    method, headers, body: body instanceof Blob || body === undefined ? body : JSON.stringify(body),
    credentials: 'same-origin',
  })
  const data = await response.json().catch(() => null)
  if (response.status === 401 && !path.startsWith('/auth')) account.value = null
  if (!response.ok || data === null) throw new Error(data?.error || 'Server bilan bog‘lanib bo‘lmadi.')
  return data
}

export function initialize() {
  return initial ||= api('/auth/me').then(data => { account.value = data.account }).catch(() => { initial = undefined })
}
export const dateTime = value => value ? new Intl.DateTimeFormat('uz-Latn-UZ', {
  dateStyle: 'medium', timeStyle: 'medium', timeZone: 'Asia/Tashkent',
}).format(new Date(value)) : '—'
