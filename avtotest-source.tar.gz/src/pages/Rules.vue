<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import Icon from '../components/Icon.vue'
import PageHeading from '../components/PageHeading.vue'
const props = defineProps({ signs: Boolean })
const source = 'https://lex.uz/docs/-5953883'
const catalog = ref([])
const query = ref('')
const selected = ref('')
const issue = ref('')
const loading = ref(true)
const mode = ref('manual')
const fold = text => (text || '').toLocaleLowerCase().replace(/[ʻʼ‘’`']/g, '')
const sections = computed(() => catalog.value.filter(section => props.signs ? section.group === 'signs' : section.group !== 'signs'))
watch(() => props.signs, () => { query.value = ''; selected.value = ''; mode.value = 'manual' })
const illustrated = computed(() => props.signs ? catalog.value.find(section => section.id === '-7050514')?.rows.flatMap(row => row.images || []) || [] : [])
const activeSections = computed(() => {
  const search = fold(query.value.trim())
  if (!search) return sections.value.filter(item => item.id === selected.value)
  return sections.value.map(item => {
    if (fold(item.title).includes(search)) return item
    return { ...item, rows: item.rows.filter(row => fold(row.text).includes(search)) }
  }).filter(item => item.rows.length)
})
const signPreview = computed(() => {
  const code = query.value.trim()
  return props.signs && /^[1-7]\.\d{1,2}(?:\.\d{1,2})?$/.test(code) ? '/official/' + code + '.webp' : ''
})
const previewFailed = ref(false)
watch(signPreview, () => { previewFailed.value = false })
const chapterCount = computed(() => catalog.value.filter(section => section.group === 'rules').length)
watch(sections, values => {
  if (!values.some(section => section.id === selected.value)) selected.value = values.find(section => section.rows.length)?.id || ''
})
onMounted(async () => {
  try {
    const response = await fetch('/official/catalog.json')
    if (!response.ok) throw new Error()
    catalog.value = await response.json()
  } catch { issue.value = 'Rasmiy materialni yuklab bo‘lmadi.' }
  finally { loading.value = false }
})
function selectSection(event) {
  selected.value = event.target.value
  query.value = ''
}
</script>
<template>
  <PageHeading :heading="signs ? 'Yo‘l belgilari' : 'O‘zbekiston yo‘l harakati qoidalari'" :description="signs ? 'Belgi raqami yoki nomi bo‘yicha qidiring. Rasmiy chizmalar katalogda mavjud.' : '172-son qarorning Yo‘l harakati qoidalari matni va ilovalari.'">
    <a :href="source" class="button secondary" target="_blank" rel="noopener noreferrer">Lex.uz <Icon name="ArrowRight" :size="16" /></a>
  </PageHeading>
  <p v-if="issue" class="notice error" role="alert">{{ issue }}</p>
  <p v-else-if="loading" class="muted">Yuklanmoqda…</p>
  <template v-else>
    <div class="filter-bar">
      <div v-if="signs" class="segmented" aria-label="Belgilar ko‘rinishi"><button :class="{selected: mode==='manual'}" @click="mode='manual'">Ma’nolari</button><button :class="{selected: mode==='pictures'}" @click="mode='pictures'">Rasmiy rasmlar</button></div>
      <template v-if="!signs || mode==='manual'">
        <label class="search-field"><Icon name="Search" :size="18" /><input v-model="query" type="search" :aria-label="signs ? 'Belgini qidirish' : 'Qoidani qidirish'" :placeholder="signs ? 'Masalan, 2.5 yoki svetofor' : 'Qoidalardan qidiring…'" /></label>
        <select :value="selected" aria-label="Bo‘lim" class="chapter-select" @change="selectSection">
          <option v-for="item in sections.filter(section => section.rows.length)" :key="item.id" :value="item.id">{{ item.title }}</option>
        </select>
      </template>
    </div>
    <div v-if="signs && mode==='pictures'" class="official-gallery">
      <a v-for="(image,i) in illustrated" :key="image" :href="image" class="card official-sheet" target="_blank" rel="noopener"><img :src="image" :alt="'Lex.uz rasmiy jadvali ' + (i+1)" loading="lazy" /><span>Rasmni kattalashtirish <Icon name="ArrowRight" :size="16" /></span></a>
    </div>
    <template v-else>
      <div v-if="signPreview && !previewFailed" class="question-image sign-preview"><img :src="signPreview" :alt="query + ' yo‘l belgisi'" @error="previewFailed=true" /></div>
      <p v-if="!query && !signs" class="muted rule-count">{{ chapterCount }} ta bob · belgilar, yo‘l chiziqlari va boshqa ilovalar</p>
      <article v-for="item in activeSections" :key="item.id" class="card form-card official-text">
        <div class="section-heading"><h2>{{ item.title }}</h2><a class="text-link" :href="source+'#'+item.id" target="_blank" rel="noopener noreferrer">Manba <Icon name="ArrowRight" :size="15" /></a></div>
        <div v-for="row in item.rows" :key="row.id">
          <p v-if="row.text">{{ row.text }}</p>
          <div v-if="row.images" class="official-inline">
            <a v-for="image in row.images" :key="image" :href="image" target="_blank" rel="noopener"><img :src="image" alt="Lex.uz rasmiy ilovasi" loading="lazy" /></a>
          </div>
        </div>
      </article>
      <p v-if="!activeSections.length" class="card form-card muted">Mos matn topilmadi.</p>
    </template>
  </template>
</template>
