<script setup>
import { computed, reactive, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import Icon from '../components/Icon.vue'
import { account, api, registeredEmail } from '../services/api.js'

const props = defineProps({ register: Boolean, admin: Boolean })
const router = useRouter()
const route = useRoute()
const form = reactive({ name: '', email: props.admin ? '' : registeredEmail.value, password: '', confirm: '' })
const busy = ref(false)
const issue = ref('')
const show = ref(false)
const heading = computed(() => props.admin ? 'Admin paneliga kirish' : props.register ? 'Akkaunt ochish' : 'Platformaga kirish')
const safeNext = computed(() => typeof route.query.next === 'string' && /^\/(tests|attempt\/[a-f0-9-]{36})$/.test(route.query.next) ? route.query.next : '/tests')
watch(() => props.register, () => { form.password = ''; form.confirm = ''; issue.value = ''; show.value = false })
watch(registeredEmail, email => { if (!props.admin && email) form.email = email })
async function submit() {
  busy.value = true
  issue.value = ''
  try {
    if (props.register) {
      await api('/auth/register', { method: 'POST', body: form })
      registeredEmail.value = form.email
      await router.replace({ path: '/login', query: { registered: '1', next: safeNext.value } })
    } else {
      const result = await api('/auth/login', { method: 'POST', body: {
        email: form.email, password: form.password, kind: props.admin ? 'admin' : 'learner',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      } })
      account.value = result.account
      registeredEmail.value = ''
      await router.replace(props.admin ? '/admin' : safeNext.value)
    }
    form.password = ''
    form.confirm = ''
  } catch (error) { issue.value = error.message }
  finally { busy.value = false }
}
</script>
<template>
  <section class="card form-card centered-form">
    <span class="icon-tile mint"><Icon :name="admin ? 'ShieldCheck' : 'UserRound'" /></span>
    <h1>{{ heading }}</h1>
    <p class="muted">{{ admin ? 'Administrator uchun alohida kirish.' : register ? 'Gmail yoki boshqa email manzilingizni ishlating.' : 'Email va ro‘yxatdan o‘tishda belgilagan parolingizni kiriting.' }}</p>
    <p v-if="!register && !admin && route.query.registered === '1'" class="notice success" role="status">Akkaunt yaratildi. Endi email va parolingiz bilan kiring.</p>
    <form class="form-stack" @submit.prevent="submit">
      <label v-if="register">Ism<input v-model="form.name" autocomplete="name" minlength="2" maxlength="80" required /></label>
      <label>Email<input v-model="form.email" type="email" autocomplete="username" maxlength="254" required /></label>
      <label>Parol<span class="password-field"><input v-model="form.password" :type="show ? 'text' : 'password'" :autocomplete="register ? 'new-password' : 'current-password'" minlength="10" maxlength="128" required /><button class="icon-button" type="button" :aria-label="show ? 'Parolni yashirish' : 'Parolni ko‘rsatish'" @click="show = !show"><Icon :name="show ? 'EyeOff' : 'Eye'" :size="18" /></button></span></label>
      <label v-if="register">Parolni tasdiqlang<input v-model="form.confirm" :type="show ? 'text' : 'password'" autocomplete="new-password" minlength="10" maxlength="128" required /></label>
      <p v-if="issue" class="notice error" role="alert">{{ issue }}</p>
      <button type="submit" class="button primary" :disabled="busy">{{ busy ? 'Yuklanmoqda…' : register ? 'Ro‘yxatdan o‘tish' : 'Kirish' }} <Icon name="ArrowRight" :size="16" /></button>
    </form>
    <p v-if="!admin" class="muted"><RouterLink class="text-link" :to="{path: register ? '/login' : '/register', query:{next:safeNext}}">{{ register ? 'Akkauntim bor · kirish' : 'Yangi akkaunt ochish' }}</RouterLink></p>
    <p class="fine-print">Kirish va qurilma ma’lumotlari haqida <RouterLink class="text-link" to="/privacy">maxfiylik sahifasi</RouterLink>.</p>
  </section>
</template>
