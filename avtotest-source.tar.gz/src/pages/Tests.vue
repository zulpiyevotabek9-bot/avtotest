<script setup>
import { onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import Icon from '../components/Icon.vue'
import PageHeading from '../components/PageHeading.vue'
import { account, api, dateTime } from '../services/api.js'

const router = useRouter()
const topics = ref([])
const history = ref({ rows: [], open: null })
const issue = ref('')
const busy = ref('')
onMounted(async () => {
  try { topics.value = await api('/topics') } catch (error) { issue.value = error.message }
})
watch(account, async user => {
  history.value = { rows: [], open: null }
  if (user) {
    try { history.value = await api('/attempts') } catch (error) { issue.value = error.message }
  }
}, { immediate: true })
async function begin(topic) {
  if (!account.value) return router.push({ path: '/login', query: { next: '/tests' } })
  busy.value = topic
  issue.value = ''
  try {
    const attempt = await api('/attempts', { method: 'POST', body: { topic } })
    await router.push('/attempt/' + attempt.id)
  } catch (error) { issue.value = error.message } finally { busy.value = '' }
}
</script>
<template>
  <PageHeading heading="Testlar" description="20 tagacha rasmli savol · 25 daqiqa · o‘tish chegarasi 80%" />
  <p v-if="issue" class="notice error" role="alert">{{ issue }}</p>
  <div v-if="history.open" class="card callout"><Icon name="Timer" /><div><strong>Tugallanmagan test bor</strong><p>Javoblaringiz saqlangan.</p></div><RouterLink :to="'/attempt/' + history.open.id" class="button primary">Davom ettirish <Icon name="ArrowRight" :size="16" /></RouterLink></div>
  <div class="content-grid">
    <article v-for="item in topics" :key="item.id" class="card test-card">
      <span class="icon-tile" :class="item.id === 'all' ? 'mint' : 'blue'"><Icon :name="({a:'Bike',b:'CarFront',c:'Truck',d:'Bus',signs:'Signpost',mechanics:'Wrench',motorcycle:'Bike',freight:'Truck',bus:'Bus',intersections:'Waypoints',safety:'ShieldCheck','first-aid':'HeartPulse'})[item.id] || 'ClipboardList'" /></span>
      <h2>{{ item.title }}</h2>
      <p class="test-facts">{{ item.count }} ta savol bankda</p>
      <button class="button secondary" :disabled="!!busy || !item.count || !!history.open" @click="begin(item.id)">{{ busy === item.id ? 'Yuklanmoqda…' : 'Boshlash' }} <Icon name="ArrowRight" :size="16" /></button>
    </article>
  </div>
  <section v-if="account" class="card dashboard-card dashboard-section"><h2>Test natijalari</h2>
    <ul v-if="history.rows.length" class="attempt-list">
      <li v-for="row in history.rows" :key="row.id"><RouterLink class="attempt-row" :to="'/attempt/' + row.id"><span class="attempt-name"><strong>{{ row.title }}</strong><small>{{ dateTime(row.finished_at) }}</small></span><strong>{{ row.correct }} / {{ row.total }}</strong><Icon name="ChevronRight" :size="17" /></RouterLink></li>
    </ul>
    <p v-else class="muted spacer">Yakunlangan testlar shu yerda ko‘rinadi.</p>
  </section>
</template>
