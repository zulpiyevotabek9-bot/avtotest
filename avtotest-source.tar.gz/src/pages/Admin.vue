<script setup>
import { computed, onBeforeUnmount, reactive, ref, watch } from 'vue'
import Auth from './Auth.vue'
import Icon from '../components/Icon.vue'
import PageHeading from '../components/PageHeading.vue'
import { account, api, dateTime } from '../services/api.js'

const topics = ref([])
const tab = ref('logs')
const search = ref('')
const page = ref(1)
const listing = ref({ rows: [], more: false })
const busy = ref(false)
const deleting = ref(false)
const issue = ref('')
const result = ref('')
const editor = ref(null)
const file = ref(null)
const preview = ref('')
let refresh = 0
let searchTimer
const authorized = computed(() => account.value?.role === 'admin')
const regions = new Intl.DisplayNames(['uz'], { type: 'region' })
const country = value => value ? regions.of(value) : '—'
function showTab(next) {
  tab.value = next
  page.value = 1
  editor.value = null
  clearPreview()
  listing.value = { rows: [], more: false }
  result.value = ''
  if (search.value) search.value = ''
  else load()
}
async function load() {
  if (!authorized.value) return
  const generation = ++refresh
  issue.value = ''
  busy.value = true
  try {
    const data = await api('/admin/' + tab.value + '?' + new URLSearchParams({ q: search.value, page: page.value }))
    if (refresh === generation) listing.value = data
  } catch (error) { if (refresh === generation) issue.value = error.message }
  finally { if (refresh === generation) busy.value = false }
}
watch(authorized, async allowed => {
  if (!allowed) return
  load()
  try { topics.value = (await api('/topics')).slice(5) } catch (error) { issue.value = error.message }
}, { immediate: true })
watch(search, () => {
  clearTimeout(searchTimer)
  page.value = 1
  searchTimer = setTimeout(load, 230)
})
onBeforeUnmount(() => { clearTimeout(searchTimer); clearPreview() })
function turn(step) { page.value += step; load() }
function clearPreview() {
  if (preview.value) URL.revokeObjectURL(preview.value)
  preview.value = ''
  file.value = null
}
function edit(row) {
  clearPreview()
  result.value = ''
  editor.value = row ? reactive({ ...row, options: [...row.options] }) : reactive({ topic: 'signs', text: '', options: ['', '', '', ''], answer: 0, explanation: '', image: '' })
}
function choose(event) {
  clearPreview()
  const next = event.target.files?.[0]
  if (!next) return
  file.value = next
  preview.value = URL.createObjectURL(next)
}
async function save() {
  const row = editor.value
  deleting.value = true
  issue.value = ''
  try {
    if (file.value) {
      if (file.value.size > 4 * 1024 * 1024) throw new Error('Rasm hajmi 4 MB dan oshmasin.')
      row.image = (await api('/admin/images', { method:'POST', body:file.value })).image
      clearPreview()
    }
    await api('/admin/questions' + (row.id ? '/' + row.id : ''), { method: row.id ? 'PUT' : 'POST', body: row })
    editor.value = null
    result.value = 'Savol saqlandi.'
    await load()
  } catch (error) { issue.value = error.message } finally { deleting.value = false }
}
async function remove(row) {
  if (!window.confirm('Bu savol test bankidan olib tashlansinmi?')) return
  deleting.value = true
  issue.value = ''
  try {
    await api('/admin/questions/' + row.id, { method: 'DELETE' })
    if (editor.value?.id === row.id) { editor.value = null; clearPreview() }
    result.value = 'Savol bankdan olib tashlandi.'
    await load()
  } catch (error) { issue.value = error.message } finally { deleting.value = false }
}
</script>
<template>
  <Auth v-if="!authorized" admin />
  <template v-else>
    <PageHeading heading="Admin panel" description="Kirish faolligi va rasmli savollar banki." />
    <div class="filter-bar">
      <div class="segmented" aria-label="Admin bo‘limlari">
        <button :class="{selected: tab==='logs'}" @click="showTab('logs')">Kirish jurnali</button>
        <button :class="{selected: tab==='questions'}" @click="showTab('questions')">Savollar</button>
      </div>
      <label class="search-field"><Icon name="Search" :size="18" /><input v-model="search" type="search" :placeholder="tab==='logs' ? 'Ism yoki email' : 'Savol matni'" aria-label="Qidirish" /></label>
      <button v-if="tab==='questions'" class="button primary" @click="edit(null)"><Icon name="Plus" :size="17" /> Savol qo‘shish</button>
      <button v-else class="button secondary" :disabled="busy" @click="load">Yangilash</button>
    </div>
    <p v-if="issue" class="notice error" role="alert">{{ issue }}</p>
    <p v-if="result" class="notice success" role="status">{{ result }}</p>
    <template v-if="tab==='logs'">
      <p class="muted rule-count">Vaqt Toshkent mintaqasida. Jurnal {{ listing.retention || 30 }} kun saqlanadi. {{ listing.hasGeo ? 'Mamlakat IP bo‘yicha taxmin qilinadi.' : 'Mamlakatni aniqlash uchun GeoIP bazasi ulanmagan.' }}</p>
      <p v-if="listing.hasGeo" class="muted rule-count">IP manbasi <a class="text-link" href="https://db-ip.com/db/lite.php" target="_blank" rel="noopener noreferrer">IP Geolocation by DB-IP</a></p>
      <div class="card data-table" role="region" aria-label="Kirish jurnali" tabindex="0">
        <table>
          <thead><tr><th>Vaqt</th><th>Foydalanuvchi</th><th>Tarmoq va mamlakat</th><th>Qurilma va tizim</th><th>Brauzer</th><th>Vaqt mintaqasi</th></tr></thead>
          <tbody><tr v-for="row in listing.rows" :key="row.id">
            <td>{{ dateTime(row.at) }}</td><td><strong>{{ row.name }}</strong><small>{{ row.email }} · {{ row.role==='admin' ? 'Admin' : 'O‘quvchi' }}</small></td>
            <td>{{ country(row.country) }}<small>{{ row.network || '—' }}</small></td>
            <td>{{ row.device || 'Aniqlanmadi' }}<small>{{ row.os || '—' }}</small></td><td>{{ row.browser || '—' }}</td><td>{{ row.timezone || '—' }}</td>
          </tr></tbody>
        </table>
        <p v-if="!listing.rows.length" class="muted form-card">{{ busy ? 'Yuklanmoqda…' : 'Kirish yozuvi topilmadi.' }}</p>
      </div>
    </template>
    <template v-else>
      <section v-if="editor" class="card form-card editor-card">
        <h2>{{ editor.id ? 'Savolni tahrirlash' : 'Yangi savol' }}</h2>
        <form class="form-stack spacer" @submit.prevent="save">
          <label>Mavzu<select v-model="editor.topic"><option v-for="item in topics" :key="item.id" :value="item.id">{{ item.title }}</option></select></label>
          <label>Savol matni<textarea v-model="editor.text" rows="3" maxlength="1200" required></textarea></label>
          <div class="form-grid"><label v-for="(_option,i) in editor.options" :key="i">Javob {{ 'ABCD'[i] }}<input v-model="editor.options[i]" maxlength="500" required /></label></div>
          <label>To‘g‘ri javob<select v-model.number="editor.answer"><option v-for="(letter,i) in 'ABCD'" :key="letter" :value="i">{{ letter }}</option></select></label>
          <label>Izoh<textarea v-model="editor.explanation" rows="3" maxlength="2500" required></textarea></label>
          <label>Rasm yuklash<input type="file" accept="image/png,image/webp,image/jpeg" :required="!editor.image" @change="choose" /></label>
          <div v-if="preview || editor.image" class="question-image"><img :src="preview || editor.image" alt="Savol rasmi" /></div>
          <div class="button-row"><button class="button primary" :disabled="deleting" type="submit">Saqlash</button><button class="button secondary" type="button" @click="editor=null;clearPreview()">Bekor qilish</button></div>
        </form>
      </section>
      <ul v-if="listing.rows.length" class="card admin-list">
        <li v-for="row in listing.rows" :key="row.id"><span class="admin-thumbnail"><img :src="row.image" alt="" loading="lazy" /></span><span class="admin-row-text"><strong>{{ row.text }}</strong><small>{{ topics.find(item=>item.id===row.topic)?.title }}</small></span>
          <div class="admin-row-actions"><button class="icon-button control" aria-label="Tahrirlash" @click="edit(row)"><Icon name="Pencil" :size="17" /></button><button class="icon-button control delete-button" :disabled="deleting" aria-label="O‘chirish" @click="remove(row)"><Icon name="Trash2" :size="17" /></button></div>
        </li>
      </ul>
      <p v-else class="card form-card muted">{{ busy ? 'Yuklanmoqda…' : 'Savol topilmadi.' }}</p>
    </template>
    <div class="button-row spacer"><button class="button secondary" :disabled="busy || page<=1" @click="turn(-1)">Oldingi</button><span class="muted">{{ page }}-sahifa</span><button class="button secondary" :disabled="busy || !listing.more" @click="turn(1)">Keyingi</button></div>
  </template>
</template>
