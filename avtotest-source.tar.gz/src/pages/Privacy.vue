<template>
  <article class="card form-card privacy-copy">
    <h1>Maxfiylik</h1>
    <p>Platforma akkaunt uchun ism, email va parol xeshini saqlaydi. Test javoblari va natijalari akkauntingizga bog‘lanadi.</p>
    <p>Muvaffaqiyatli kirishda vaqt, IP manzilining qisqartirilgan tarmoq prefiksi, brauzer bildirgan qurilma, operatsion tizim, brauzer versiyasi va vaqt mintaqasi jurnalga yoziladi. Tarmoq manbasi yoqilgan bo‘lsa, taxminiy mamlakat ham ko‘rsatiladi. GPS joylashuvi olinmaydi. Qurilma modeli brauzer yuborgan ma’lumotga bog‘liq.</p>
    <p>Kirish jurnalini faqat administrator ko‘radi. Jurnal cheklangan muddat saqlanadi, standart muddat 30 kun. Kirish seansi HttpOnly cookie orqali ishlaydi.</p>
  </article>
</template>
