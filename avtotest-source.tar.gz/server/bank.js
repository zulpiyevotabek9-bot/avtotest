import { readFile } from 'node:fs/promises'

export const topicNames = {
  all: 'Aralash sinov', a: 'A · Mototsikl', b: 'B · Yengil avtomobil',
  c: 'C · Yuk avtomobili', d: 'D · Avtobus',
  signs: 'Yo‘l belgilari', rules: 'Yo‘l harakati qoidalari', intersections: 'Chorrahalar',
  mechanics: 'Avtomobil tuzilishi va texnik xizmat', motorcycle: 'Mototsikl amaliyoti',
  freight: 'Yuk tashish va transport', bus: 'Yo‘lovchi tashish',
  safety: 'Yo‘l xavfsizligi', 'first-aid': 'YTH va birinchi yordam',
}
export const editTopics = Object.keys(topicNames).slice(5)
const extension = [
  ['mechanics','engine','Dvigatel moyining asosiy vazifasi nima?','Ishqalanadigan qismlarni moylash','Akkumulyator zaryadini oshirish','Shinani sovitish','Tormoz suyuqligini almashtirish','Moy metall yuzalar orasidagi ishqalanish va yeyilishni kamaytiradi.'],
  ['mechanics','engine','Dvigatel haddan tashqari qiziganida panel qaysi ma’lumotni ko‘rsatishi mumkin?','Sovitish suyuqligi harorati yuqoriligini','Bagaj qopqog‘i ochiqligini','Yonilg‘i baki to‘lganini','Tashqi chiroqlar yoqilganini','Harorat indikatori dvigatelning sovitish tizimi holati haqida ogohlantiradi.'],
  ['mechanics','engine','Qizigan sovitish tizimining qopqog‘ini darhol ochish nimasi bilan xavfli?','Bosim ostidagi issiq suyuqlik yoki bug‘ chiqishi mumkin','Tormoz disklari erib ketadi','G‘ildiraklar bloklanadi','Yonilg‘i baki to‘ladi','Dvigatel sovimaguncha ishlab chiqaruvchi yo‘riqnomasiga amal qiling. Bosim ostidagi tizim kuyishga olib kelishi mumkin.'],
  ['mechanics','electrical','Dvigatel ishlaganda elektr tizimida generatorning vazifasi nima?','Elektr iste’molchilarini ta’minlash va akkumulyatorni zaryadlash','Tormoz suyuqligini aylantirish','Dvigatel moyini filtrlash','Rul g‘ildiragini bloklash','Generator mexanik energiyani elektr energiyasiga aylantiradi.'],
  ['mechanics','electrical','Starter nima uchun ishlatiladi?','Ishga tushirish paytida dvigatelni aylantirish uchun','Tezlikni o‘lchash uchun','Shinaga havo yuborish uchun','Konditsionerni sovitish uchun','Starter ishga tushirish uchun zarur dastlabki aylanishni hosil qiladi.'],
  ['mechanics','brakes','ABS tizimining asosiy vazifasi nima?','Tormozlashda g‘ildiraklarning to‘liq bloklanishiga qarshi ishlash','To‘xtab turgan mashinani doim avtomatik ishga tushirish','Dvigatel haroratini pasaytirish','Moy darajasini o‘lchash','ABS g‘ildirak tezligini kuzatib, tormoz bosimini boshqaradi.'],
  ['mechanics','tyres','Shinalar bosimi bo‘yicha qaysi ko‘rsatkichga tayanasiz?','Transport vositasining ishlab chiqaruvchi ko‘rsatmasiga','Boshqa modeldagi mashinaning maksimal bosimiga','Shinaning rangiga','Faqat rul diametriga','Tavsiya etilgan bosim avtomobil yo‘riqnomasi yoki ishlab chiqaruvchi yorlig‘ida ko‘rsatiladi.'],
  ['mechanics','tyres','Protektorning notekis yeyilishi aniqlansa, nimalarni tekshirish foydali?','Shina bosimi va g‘ildirak geometriyasini','O‘rindiq kamari rangini','Media tizimi ovozini','Avtomobil raqamini','Bosim, g‘ildirak geometriyasi yoki osma nosozligi yeyilish shakliga ta’sir qilishi mumkin.'],
  ['mechanics','dashboard','Panelda moy bosimi kimga oid ko‘rsatkich?','Dvigatel moylash tizimiga','Old o‘rindiqlar isitishiga','Yoqilg‘i narxiga','Shisha yuvish suyuqligi haroratiga','Moy bosimi ogohlantirishiga ishlab chiqaruvchi yo‘riqnomasi bo‘yicha munosabat bildiriladi.'],
  ['mechanics','engine','Havo filtri nimani kamaytiradi?','Dvigatelga kiradigan havodagi chang va zarrachalarni','Shinalardagi bosimni','Tutqichning aylanishini','Akkumulyator sig‘imini','Havo filtri chang va boshqa zarrachalarni ushlab qoladi.'],
  ['motorcycle','motorcycle','Mototsikl shlemi himoyani ta’minlashi uchun qanday bo‘lishi kerak?','Mos o‘lchamda va iyak tasmasi mahkamlangan','Boshdan oson chiqadigan darajada katta','Faqat yo‘lovchining qo‘lida','Tasma ochiq va shlem orqaga surilgan','Mos o‘lcham va mahkamlangan tasma shlemning joyida qolishiga yordam beradi.'],
  ['motorcycle','motorcycle','Yomg‘irda mototsikl boshqaruvida qanday odat foydali?','Tezlikni yo‘lga moslash va harakatlarni silliq bajarish','Keskin tezlashib xavfli joydan o‘tish','Har burilishda birdaniga tormozlash','Yo‘l chiziqlariga ataylab keskin chiqish','Ho‘l sirt sirpanishni kuchaytirishi mumkin. Silliq boshqaruv va masofa xavfni kamaytiradi.'],
  ['motorcycle','motorcycle','Safardan oldin mototsiklda qaysi qismlarni ko‘zdan kechirasiz?','Shinalar, tormozlar va chiroqlarni','Faqat bo‘yoqni','Faqat shlem rangini','Faqat hujjat g‘ilofini','Tormoz, shina va chiroqlar xavfsiz boshqaruv va ko‘rinish uchun zarur.'],
  ['motorcycle','motorcycle','Nega mototsikl boshqa mashinaning ko‘rinmas hududida uzoq qolmasligi kerak?','U mashina haydovchisining oynasida ko‘rinmay qolishi mumkin','Uning kuzovi haddan tashqari qiziydi','Yo‘l belgilarining shakli o‘zgaradi','Yonilg‘i darajasi aniqlanmay qoladi','Oynada ko‘rinmaydigan zona kattaroq transport vositalarida ayniqsa muhim.'],
  ['motorcycle','motorcycle','Mototsikl burilishga kirishidan oldin haydovchi nimani rejalashtiradi?','Ko‘rinishga mos tezlik va yo‘nalishni','Faqat motor tovushini','Shlemning rangini','Orqa g‘ildirak diametrini o‘zgartirishni','Burilishdan oldin yo‘l holati va ko‘rinishni baholash xavfsiz boshqarishga yordam beradi.'],
  ['freight','freight','Yuk tashishdan oldin eng muhim tekshiruvlardan biri qaysi?','Yukning joylashuvi va mahkamlanganini tekshirish','Faqat rangini kuzatish','Yukni imkon qadar baland yig‘ish','Orqa oynalarni buklab qo‘yish','Mahkamlanmagan yuk siljib, boshqaruvga yoki yo‘l harakati ishtirokchilariga xavf tug‘dirishi mumkin.'],
  ['freight','freight','Yuk mashinasining o‘qi haddan tashqari yuklanishini kamaytirish uchun nima qilinadi?','Og‘irlik ruxsat etilgan o‘q yuklariga mos taqsimlanadi','Yuk bitta orqa burchakka yig‘iladi','Tormoz ogohlantirishi o‘chirib qo‘yiladi','Shinalar bo‘shatiladi','Umumiy massa bilan birga o‘qlar bo‘yicha yukni ham tekshirish kerak.'],
  ['freight','freight','Yuk mashinasi burilishidan oldin nega yonidagi joyni tekshirish kerak?','Orqa g‘ildiraklar old g‘ildiraklardan torroq yoy bo‘ylab yurishi mumkin','Barcha oynalar avtomatik qoplanadi','Burilishda har doim orqaga yuriladi','Yuk qopqog‘i o‘zidan ochiladi','Uzun mashina burilganda ichki tomonda ko‘proq joy talab qilishi mumkin.'],
  ['freight','freight','Yuk tashishda og‘irlik markazining baland bo‘lishi qanday xavfni oshiradi?','Burilishda ag‘darilish xavfini','Old chiroqning yonmasligini','Yonilg‘i rangining o‘zgarishini','Radioga shovqin kirishini','Baland og‘irlik markazi yon barqarorlikka ta’sir qiladi.'],
  ['freight','freight','Tirkama ulangandan keyin safar oldidan nimani tekshirasiz?','Ulash moslamasi, chiroqlar va tegishli tormoz ulanishlarini','Faqat tirkama bo‘yog‘ini','Faqat radio kanallarini','Qo‘shimcha oynalarni olib tashlashni','Biriktirish va ulanishlar ishlashini ishlab chiqaruvchi tartibida tekshirish zarur.'],
  ['bus','bus','Yo‘lovchilar tushib-chiqayotganida avtobus haydovchisi nima qiladi?','Avtobusni to‘xtatib turadi va eshik zonasini kuzatadi','Avtobusni asta harakatlantiradi','Yo‘lovchilarni eshik yopilayotganda tushiradi','Tushishni qatnov qismi o‘rtasida boshlaydi','Eshik zonasida yo‘lovchilar borida transportni harakatlantirish xavf tug‘diradi.'],
  ['bus','bus','Avtobus bekatdan ketishidan oldin qaysi tekshiruv zarur?','Eshiklar yopilganini va yo‘lga xavfsiz qo‘shilishni tekshirish','Faqat salon haroratini tekshirish','Orqa oynalarni buklab qo‘yish','Faqat radio ovozini oshirish','Yo‘lovchilar xavfsizligi uchun eshiklar va yo‘l holati birga tekshiriladi.'],
  ['bus','bus','Salonda tik turgan yo‘lovchilar bo‘lsa, haydash uslubi qanday bo‘lishi ma’qul?','Tezlanish va tormozlashni imkon qadar silliq bajarish','Har bekatda keskin tormozlash','Burilishda tezlikni keskin oshirish','Tutqichlar oldini yuk bilan to‘sish','Silliq boshqaruv yo‘lovchilarning yiqilish ehtimolini kamaytiradi.'],
  ['bus','bus','Safar oldidan favqulodda chiqishlarga tegishli qaysi holatni tekshirish kerak?','Chiqishlar foydalanish uchun ochiq va yo‘li bo‘shligini','Chiqishlar yuk bilan to‘silganini','Chiqish joyi hech kimga ko‘rinmasligini','Chiqish belgilari olib tashlanganini','Favqulodda chiqishlar yo‘lovchilarning xavfsiz evakuatsiyasiga xizmat qiladi.'],
  ['bus','bus','Bekat yonida shoshilayotgan piyodalarni ko‘rsangiz, qaysi yondashuv xavfsiz?','Tezlikni pasaytirib, atrof va ko‘rinmas hududlarni kuzatish','Signal bilan yo‘lovchilarni shoshirish','Bekatni yuqori tezlikda kesib o‘tish','Faqat oldinga qarash','Bekatlarda piyodalar transport orqasidan yoki yonidan chiqishi mumkin.'],
]
function load(name) {
  return readFile(new URL(name, import.meta.url), 'utf8').then(JSON.parse)
}
export async function bank() {
  const [baseline, signs] = await Promise.all([load('practice-baseline.json'), load('verified-signs.json')])
  const originals = baseline.map(row => {
    const sourceTopic = row.categories[0]
    const topic = sourceTopic === 'operation' ? 'mechanics' : sourceTopic
    return {
      id: row.id, topic, text: row.text, options: row.options, answer: row.correct,
      explanation: row.explanation.replace('16-bob piyodalarni', '17-bob piyodalarni'),
      image: row.image || '/scenarios/' + topic + '.webp',
    }
  })
  const signEntries = Object.entries(signs)
  const recognition = signEntries.map(([code, name], index) => {
    const distinct = signEntries.filter(([candidate, label]) => candidate !== code && label !== name)
    return {
      id: 'lex-' + code, topic: 'signs', text: 'Rasmdagi yo‘l belgisi nimani anglatadi?',
      options: [name, ...[1, 7, 19].map(step => distinct[(index + step) % distinct.length][1])],
      answer: 0, explanation: code + ' — ' + name + '. Manba: 172-son qaror, YHQga 1-ilova.',
      image: '/official/' + code + '.webp',
    }
  })
  const practical = extension.map(([topic, picture, text, correct, a, b, c, explanation], index) => ({
    id: 'avto-' + (index + 1), topic, text, options: [correct, a, b, c], answer: 0, explanation,
    image: '/scenarios/' + picture + '.webp',
  }))
  return [...originals, ...recognition, ...practical]
}
