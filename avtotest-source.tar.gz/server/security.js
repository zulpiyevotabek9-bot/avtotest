import { createHash, randomBytes, scrypt, timingSafeEqual } from 'node:crypto'
import { promisify } from 'node:util'

const derive = promisify(scrypt)
const cost = { N: 32768, r: 8, p: 3, maxmem: 64 * 1024 * 1024 }
export const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
export const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
export const normalizeEmail = value => typeof value === 'string' ? value.trim().toLowerCase() : ''
export const digest = value => createHash('sha256').update(value).digest('hex')
export const newToken = () => randomBytes(32).toString('base64url')
export const passwordOk = password => typeof password === 'string' && password.length >= 10 && password.length <= 128
export async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex')
  return salt + ':' + (await derive(password, salt, 32, cost)).toString('hex')
}
export async function passwordMatches(password, stored) {
  const [salt, hash] = stored.split(':')
  const derived = await derive(password, salt, 32, cost)
  return timingSafeEqual(derived, Buffer.from(hash, 'hex'))
}

export function readCookie(header, key) {
  for (const entry of (header || '').split(';')) {
    const [name, value] = entry.trim().split('=')
    if (name === key && /^[A-Za-z0-9_-]{43}$/.test(value || '')) return value
  }
  return ''
}
