<script setup>
import {
  ArrowDownToLine, ArrowLeft, ArrowRight, BarChart3, Bike, BookOpen, Bus, CalendarDays, CarFront,
  ChartNoAxesCombined, Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, CircleHelp,
  ClipboardList, Clock3, Database, Eye, EyeOff, FileDown, FileQuestion, FileUp, Flame, Gauge,
  Globe2, HeartPulse, House, Image, Info, Languages, LayoutGrid, ListChecks, LockKeyhole, LogIn, LogOut,
  Menu, Moon, Pencil, Plus, Route, Search, Settings, ShieldCheck, Signpost, Sparkles, Star, Sun,
  Target, Timer, Trash2, Trophy, Truck, UserRound, UsersRound, Waypoints, Wrench, X, XCircle,
} from '@lucide/vue'

const icons = {
  ArrowDownToLine, ArrowLeft, ArrowRight, BarChart3, Bike, BookOpen, Bus, CalendarDays, CarFront,
  ChartNoAxesCombined, Check, CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, CircleHelp,
  ClipboardList, Clock3, Database, Eye, EyeOff, FileDown, FileQuestion, FileUp, Flame, Gauge,
  Globe2, HeartPulse, House, Image, Info, Languages, LayoutGrid, ListChecks, LockKeyhole, LogIn, LogOut,
  Menu, Moon, Pencil, Plus, Route, Search, Settings, ShieldCheck, Signpost, Sparkles, Star, Sun,
  Target, Timer, Trash2, Trophy, Truck, UserRound, UsersRound, Waypoints, Wrench, X, XCircle,
}
defineProps({ name: String, size: { type: Number, default: 20 } })
</script>
<template><component :is="icons[name] || LayoutGrid" :size="size" :stroke-width="1.8" aria-hidden="true" /></template>
