<script setup>
defineProps({ heading: String, description: String })
</script>
<template>
  <header class="page-heading">
    <div><h1>{{ heading }}</h1><p v-if="description">{{ description }}</p></div>
    <div v-if="$slots.default" class="heading-actions"><slot /></div>
  </header>
</template>
