<script setup>
import Icon from '../components/Icon.vue'
const options = [
  ['/tests','ClipboardList','mint','Rasmli testlar','A–D toifalari, aralash sinov va avtomobilga oid mavzular.'],
  ['/rules','BookOpen','blue','Yo‘l harakati qoidalari','172-son qaror bilan tasdiqlangan qoidalar va ularning ilovalari.'],
  ['/signs','Signpost','amber','Yo‘l belgilari','Belgi raqami, ma’nosi va rasmiy chizmalar.'],
]
</script>
<template>
  <section class="hero platform-hero">
    <div class="hero-copy">
      <div class="hero-label"><Icon name="Route" :size="17" /> O‘ZBEKISTON HAYDOVCHILIK NAZARIYASI</div>
      <h1>Imtihonga rasmli testlar bilan tayyorlaning</h1>
      <p>Yo‘l belgilarini o‘rganing, avtomobil bo‘yicha bilimlaringizni sinang va natijalaringizni kuzating.</p>
      <div class="button-row">
        <RouterLink to="/tests" class="button primary">Test tanlash <Icon name="ArrowRight" :size="17" /></RouterLink>
        <RouterLink to="/rules" class="button hero-secondary">Qoidalarni o‘qish</RouterLink>
      </div>
    </div>
    <div class="hero-art" aria-hidden="true">
      <span class="orbit orbit-outer"></span><span class="orbit orbit-inner"></span>
      <div class="road road-lower"></div><div class="road road-upper"></div>
      <div class="hero-dial"><div><Icon name="Gauge" :size="66" /></div></div>
      <div class="hero-marker marker-sign"><Icon name="Signpost" :size="22" /></div>
    </div>
  </section>
  <div class="content-grid home-options">
    <RouterLink v-for="[path, icon, tone, title, description] in options" :key="path" :to="path" class="card form-card home-action">
      <span class="icon-tile" :class="tone"><Icon :name="icon" /></span>
      <h2>{{ title }}</h2><p class="muted">{{ description }}</p>
      <span class="text-link">Ochish <Icon name="ArrowRight" :size="16" /></span>
    </RouterLink>
  </div>
</template>
