import pg from 'pg'
import { readFile } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import { emailPattern, hashPassword, normalizeEmail, passwordOk } from './security.js'
import { bank } from './bank.js'

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_CA ? { ca: process.env.DATABASE_CA, rejectUnauthorized: true } : undefined,
  max: Number(process.env.PG_POOL_SIZE || 10),
  connectionTimeoutMillis: 8000,
})

export async function transaction(work) {
  const connection = await pool.connect()
  try {
    await connection.query('BEGIN')
    const result = await work(connection)
    await connection.query('COMMIT')
    return result
  } catch (error) {
    await connection.query('ROLLBACK')
    throw error
  } finally {
    connection.release()
  }
}

const configError = (code, message) => Object.assign(new Error(message), { code: 'AVTO_' + code })

export async function migrate() {
  const connection = process.env.DATABASE_URL
  if (!connection) throw configError('DB_MISSING', 'DATABASE_URL is missing. Link the PostgreSQL service in Railway Variables.')
  if (!/^postgres(?:ql)?:\/\//i.test(connection) || !URL.canParse(connection) || !new URL(connection).hostname) {
    throw configError('DB_INVALID', 'DATABASE_URL is not a PostgreSQL URL. Use the PostgreSQL service reference.')
  }
  const schema = await readFile(new URL('schema.sql', import.meta.url), 'utf8')
  const email = normalizeEmail(process.env.ADMIN_EMAIL)
  const password = process.env.ADMIN_PASSWORD
  if ((email || password) && (!emailPattern.test(email) || !passwordOk(password) || password.length < 14)) {
    throw configError('ADMIN_INVALID', 'Set a valid ADMIN_EMAIL and an ADMIN_PASSWORD of at least 14 characters.')
  }
  await transaction(async client => {
    await client.query('SELECT pg_advisory_xact_lock(423329915)')
    await client.query(schema)
    const { rowCount } = await client.query("INSERT INTO seed_migration(version) VALUES ('2026-11-25-v1') ON CONFLICT DO NOTHING")
    if (rowCount) {
      for (const q of await bank()) {
        await client.query(
          'INSERT INTO question(id,topic,text,options,answer,explanation,image) VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT DO NOTHING',
          [q.id, q.topic, q.text, JSON.stringify(q.options), q.answer, q.explanation, q.image],
        )
      }
    }
    if (email && password) {
      const { rows: [existing] } = await client.query('SELECT role FROM account WHERE email=$1', [email])
      if (existing && existing.role !== 'admin') throw configError('ADMIN_CONFLICT', 'ADMIN_EMAIL is already used by a learner. Use a separate administrator email.')
      if (!existing) await client.query("INSERT INTO account(id,email,name,password_hash,role) VALUES($1,$2,'Administrator',$3,'admin')", [
        randomUUID(), email, await hashPassword(password),
      ])
    }
    const admin = await client.query("SELECT 1 FROM account WHERE role='admin' LIMIT 1")
    if (!admin.rowCount) throw configError('ADMIN_MISSING', 'Set ADMIN_EMAIL and ADMIN_PASSWORD to create the first administrator.')
  })
}
