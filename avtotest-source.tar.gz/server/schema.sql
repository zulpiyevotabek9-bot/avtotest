CREATE TABLE IF NOT EXISTS account (
  id uuid PRIMARY KEY,
  email text NOT NULL UNIQUE,
  name text NOT NULL,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('learner','admin')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS session (
  token_hash text PRIMARY KEY,
  account_id uuid NOT NULL REFERENCES account(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS session_expiration ON session(expires_at);
CREATE TABLE IF NOT EXISTS login_event (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  account_id uuid NOT NULL REFERENCES account(id) ON DELETE CASCADE,
  at timestamptz NOT NULL DEFAULT now(),
  network text NOT NULL DEFAULT '',
  country text NOT NULL DEFAULT '',
  device text NOT NULL DEFAULT '',
  os text NOT NULL DEFAULT '',
  browser text NOT NULL DEFAULT '',
  timezone text NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS login_event_at ON login_event(at DESC, id DESC);
CREATE TABLE IF NOT EXISTS media (
  id uuid PRIMARY KEY,
  mime text NOT NULL,
  bytes bytea NOT NULL
);
CREATE TABLE IF NOT EXISTS question (
  id text PRIMARY KEY,
  topic text NOT NULL,
  text text NOT NULL,
  options jsonb NOT NULL,
  answer smallint NOT NULL CHECK(answer BETWEEN 0 AND 3),
  explanation text NOT NULL,
  image text NOT NULL,
  enabled boolean NOT NULL DEFAULT true
);
CREATE INDEX IF NOT EXISTS questions_topic ON question(topic) WHERE enabled;
CREATE TABLE IF NOT EXISTS seed_migration (
  version text PRIMARY KEY
);
CREATE TABLE IF NOT EXISTS attempt (
  id uuid PRIMARY KEY,
  account_id uuid NOT NULL REFERENCES account(id) ON DELETE CASCADE,
  title text NOT NULL,
  topic text NOT NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz NOT NULL,
  finished_at timestamptz,
  questions jsonb NOT NULL,
  answers jsonb NOT NULL,
  correct smallint
);
CREATE INDEX IF NOT EXISTS attempt_owner_date ON attempt(account_id, started_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS one_open_attempt ON attempt(account_id) WHERE finished_at IS NULL;
