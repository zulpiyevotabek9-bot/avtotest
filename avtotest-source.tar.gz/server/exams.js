import { randomInt, randomUUID } from 'node:crypto'
import { pool, transaction } from './db.js'
import { topicNames } from './bank.js'

export const minutes = 25
export const passMark = 80
export const appError = (status, message) => Object.assign(new Error(message), { status })
const topicSets = {
  all: [], a: ['signs', 'rules', 'motorcycle', 'safety', 'first-aid'],
  b: ['signs', 'rules', 'mechanics', 'safety', 'first-aid'],
  c: ['signs', 'rules', 'freight', 'mechanics', 'safety', 'first-aid'],
  d: ['signs', 'rules', 'bus', 'mechanics', 'safety', 'first-aid'],
}
const shuffle = values => {
  for (let i = values.length - 1; i > 0; i--) {
    const j = randomInt(i + 1)
    const previous = values[i]
    values[i] = values[j]
    values[j] = previous
  }
  return values
}

function output(row) {
  const result = Boolean(row.finished_at)
  const questions = result ? row.questions : row.questions.map(({ id, text, options, image }) => ({ id, text, options, image }))
  return {
    id: row.id, title: row.title, topic: row.topic, questions, answers: row.answers,
    started: row.started_at, ends: row.ends_at, finished: row.finished_at, serverTime: Date.now(),
    ...(result ? { correct: row.correct, score: Math.floor(row.correct * 100 / questions.length), passMark } : {}),
  }
}

async function finalize(client, row, at) {
  const correct = row.questions.filter((q, i) => q.answer === row.answers[i]).length
  const { rows: [result] } = await client.query(
    'UPDATE attempt SET finished_at=$2,correct=$3 WHERE id=$1 RETURNING *', [row.id, at, correct],
  )
  return result
}

export async function catalog() {
  const { rows } = await pool.query('SELECT topic, count(*)::int AS count FROM question WHERE enabled GROUP BY topic')
  return Object.entries(topicNames).map(([id, title]) => ({
    id, title, count: rows.filter(row => id === 'all' || (topicSets[id] || [id]).includes(row.topic))
      .reduce((total, row) => total + row.count, 0),
  }))
}

export async function start(user, topic) {
  if (!Object.hasOwn(topicNames, topic)) throw appError(400, 'Test bo‘limi topilmadi.')
  return transaction(async client => {
    await client.query('SELECT id FROM account WHERE id=$1 FOR UPDATE', [user])
    const { rows: [open] } = await client.query(
      'SELECT * FROM attempt WHERE account_id=$1 AND finished_at IS NULL FOR UPDATE', [user],
    )
    const now = new Date()
    if (open && open.ends_at > now) return output(open)
    if (open) await finalize(client, open, open.ends_at)
    const filter = topicSets[topic] || [topic]
    const { rows } = await client.query(
      `WITH sampled AS (
        SELECT id,topic,text,options,answer,explanation,image,
          row_number() OVER (PARTITION BY topic ORDER BY random()) AS slot
        FROM question WHERE enabled AND (cardinality($1::text[])=0 OR topic=ANY($1))
      )
      SELECT * FROM sampled ORDER BY slot,random() LIMIT 20`,
      [filter],
    )
    shuffle(rows)
    if (!rows.length) throw appError(422, 'Bu bo‘limda test savollari yo‘q.')
    const questions = rows.map(q => {
      const order = shuffle([0, 1, 2, 3])
      return { ...q, options: order.map(index => q.options[index]), answer: order.indexOf(q.answer) }
    })
    const { rows: [attempt] } = await client.query(
      'INSERT INTO attempt(id,account_id,title,topic,ends_at,questions,answers) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *',
      [randomUUID(), user, topicNames[topic], topic, new Date(+now + minutes * 60_000), JSON.stringify(questions), JSON.stringify(questions.map(() => null))],
    )
    return output(attempt)
  })
}

export async function readOrUpdate(user, id, action = {}) {
  return transaction(async client => {
    const { rows: [row] } = await client.query('SELECT * FROM attempt WHERE id=$1 AND account_id=$2 FOR UPDATE', [id, user])
    if (!row) throw appError(404, 'Urinish topilmadi.')
    if (row.finished_at) return output(row)
    const now = new Date()
    if (row.ends_at <= now || action.finish) return output(await finalize(client, row, row.ends_at <= now ? row.ends_at : now))
    if (Object.hasOwn(action, 'index')) {
      if (!Number.isInteger(action.index) || action.index < 0 || action.index >= row.answers.length
        || !Number.isInteger(action.answer) || action.answer < 0 || action.answer > 3) throw appError(400, 'Javob yaroqsiz.')
      row.answers[action.index] = action.answer
      await client.query('UPDATE attempt SET answers=$2 WHERE id=$1', [id, JSON.stringify(row.answers)])
    }
    return output(row)
  })
}

export async function history(user) {
  const { rows: [open] } = await pool.query('SELECT id, ends_at FROM attempt WHERE account_id=$1 AND finished_at IS NULL', [user])
  const expired = open && open.ends_at <= new Date()
  if (expired) await readOrUpdate(user, open.id)
  const { rows } = await pool.query(
    'SELECT id,title,started_at,finished_at,correct,jsonb_array_length(questions) AS total FROM attempt WHERE account_id=$1 AND finished_at IS NOT NULL ORDER BY finished_at DESC LIMIT 50',
    [user],
  )
  return { open: expired ? null : open || null, rows }
}
